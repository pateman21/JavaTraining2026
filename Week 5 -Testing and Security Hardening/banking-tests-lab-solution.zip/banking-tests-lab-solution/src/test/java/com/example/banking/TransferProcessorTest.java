package com.example.banking;

import com.example.banking.repository.AccountRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("Transfer processor")
class TransferProcessorTest {

    @Mock
    private AccountRepository accountRepository;

    @Mock
    private TransferService transferService;

    @InjectMocks
    private TransferProcessor transferProcessor;

    @Test
    @DisplayName("processTransfer fetches both accounts from the repository")
    void processTransferFetchesBothAccountsFromRepository() {
        Account source = new Account("ACC-001", new BigDecimal("100.00"));
        Account destination = new Account("ACC-002", new BigDecimal("0.00"));
        when(accountRepository.findById("ACC-001")).thenReturn(Optional.of(source));
        when(accountRepository.findById("ACC-002")).thenReturn(Optional.of(destination));

        transferProcessor.processTransfer("ACC-001", "ACC-002", new BigDecimal("30.00"));

        verify(accountRepository).findById("ACC-001");
        verify(accountRepository).findById("ACC-002");
    }

    @Test
    @DisplayName("processTransfer saves both accounts after a successful transfer")
    void processTransferSavesBothAccounts() {
        Account source = new Account("ACC-001", new BigDecimal("100.00"));
        Account destination = new Account("ACC-002", new BigDecimal("0.00"));
        when(accountRepository.findById("ACC-001")).thenReturn(Optional.of(source));
        when(accountRepository.findById("ACC-002")).thenReturn(Optional.of(destination));

        transferProcessor.processTransfer("ACC-001", "ACC-002", new BigDecimal("30.00"));

        verify(accountRepository, times(2)).save(any(Account.class));
    }

    @Test
    @DisplayName("processTransfer throws AccountNotFoundException when source is missing")
    void processTransferThrowsWhenSourceIsMissing() {
        when(accountRepository.findById("ACC-MISSING")).thenReturn(Optional.empty());

        assertThatThrownBy(
                () -> transferProcessor.processTransfer(
                        "ACC-MISSING", "ACC-002", new BigDecimal("30.00")))
            .isInstanceOf(AccountNotFoundException.class)
            .hasMessageContaining("ACC-MISSING");

        verify(accountRepository, never()).save(any(Account.class));
    }

    @Test
    @DisplayName("processTransfer saves the source account with the updated balance")
    void processTransferSavesSourceWithUpdatedBalance() {
        // For this test we use a real TransferService so the balance is
        // actually updated. We override the @InjectMocks construction
        // by building the processor manually with the real service.
        TransferService realTransferService = new TransferService();
        TransferProcessor processor = new TransferProcessor(accountRepository, realTransferService);

        Account source = new Account("ACC-001", new BigDecimal("100.00"));
        Account destination = new Account("ACC-002", new BigDecimal("0.00"));
        when(accountRepository.findById("ACC-001")).thenReturn(Optional.of(source));
        when(accountRepository.findById("ACC-002")).thenReturn(Optional.of(destination));

        processor.processTransfer("ACC-001", "ACC-002", new BigDecimal("30.00"));

        ArgumentCaptor<Account> captor = ArgumentCaptor.forClass(Account.class);
        verify(accountRepository, times(2)).save(captor.capture());

        List<Account> saved = captor.getAllValues();
        Account savedSource = saved.stream()
                .filter(a -> a.getAccountNumber().equals("ACC-001"))
                .findFirst()
                .orElseThrow();
        assertThat(savedSource.getBalance()).isEqualByComparingTo("70.00");
    }
}
