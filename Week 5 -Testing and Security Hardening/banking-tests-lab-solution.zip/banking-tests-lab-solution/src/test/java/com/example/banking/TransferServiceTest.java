package com.example.banking;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

@DisplayName("Transfer service")
class TransferServiceTest {

    private TransferService transferService;

    @BeforeEach
    void setUp() {
        transferService = new TransferService();
    }

    @Test
    @DisplayName("transfer reduces the source account's balance")
    void transferReducesSourceBalance() {
        Account source = new Account("ACC-001", new BigDecimal("100.00"));
        Account destination = new Account("ACC-002", new BigDecimal("0.00"));

        transferService.transfer(source, destination, new BigDecimal("30.00"));

        assertThat(source.getBalance()).isEqualByComparingTo("70.00");
    }

    @Test
    @DisplayName("transfer increases the destination account's balance")
    void transferIncreasesDestinationBalance() {
        Account source = new Account("ACC-001", new BigDecimal("100.00"));
        Account destination = new Account("ACC-002", new BigDecimal("0.00"));

        transferService.transfer(source, destination, new BigDecimal("30.00"));

        assertThat(destination.getBalance()).isEqualByComparingTo("30.00");
    }

    @Test
    @DisplayName("transfer rejects amounts greater than the source balance")
    void transferRejectsAmountGreaterThanSourceBalance() {
        Account source = new Account("ACC-001", new BigDecimal("50.00"));
        Account destination = new Account("ACC-002", new BigDecimal("0.00"));

        assertThatThrownBy(
                () -> transferService.transfer(source, destination, new BigDecimal("100.00")))
            .isInstanceOf(InsufficientFundsException.class)
            .hasMessageContaining("ACC-001");
    }

    @Test
    @DisplayName("transfer rejects when the source account is frozen")
    void transferRejectsWhenSourceIsFrozen() {
        Account source = new Account("ACC-001", new BigDecimal("100.00"), AccountStatus.FROZEN);
        Account destination = new Account("ACC-002", new BigDecimal("0.00"));

        assertThatThrownBy(
                () -> transferService.transfer(source, destination, new BigDecimal("30.00")))
            .isInstanceOf(AccountFrozenException.class)
            .hasMessageContaining("source")
            .hasMessageContaining("FROZEN");
    }

    @ParameterizedTest
    @CsvSource({
        "50,    0.50",
        "500,   1.50",
        "2500,  5.00",
        "10000, 10.00"
    })
    @DisplayName("calculateFee returns the right fee for each tier")
    void calculateFeeReturnsCorrectFeeForEachTier(BigDecimal amount, BigDecimal expectedFee) {
        BigDecimal fee = transferService.calculateFee(amount);

        assertThat(fee).isEqualByComparingTo(expectedFee);
    }
}
